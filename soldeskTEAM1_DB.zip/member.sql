 create table member ( 
 num int unsigned not null auto_increment, 
 id varchar(50) not null, 
 pass varchar(50) not null, 
 name varchar(50), 
 nick varchar(50), 
 mphone varchar(20), 
 email varchar(50), 
 regist_day varchar(30), 
 primary key(num,id) 
 );