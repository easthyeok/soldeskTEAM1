create database care_db;
